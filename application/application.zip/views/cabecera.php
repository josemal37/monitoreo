<div class="hidden-sm hidden-xs">
    <img src="<?= base_url() . 'assets/images/cabecera_sistema_monitoreo_resiliencia.png'?>" style="width: 100%" class="img-responsive">
</div>
<div class="hidden-lg hidden-md">
    <h3 class="text-center text-primary">Sistema de Monitoreo</h3>
    <h4 class="text-center">Promoción de una cultura de resiliencia</h4>
</div>